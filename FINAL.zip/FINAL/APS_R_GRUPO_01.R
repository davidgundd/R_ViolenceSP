library(plotly)
library(tidyverse)
library(readxl)
library(stringr)
library(ggthemes)
library(readxl)
require(gridExtra)
library(geobr)
library(sf)

#Importando as bases de dados

dados <- read.csv("ocorrencias_registradas.csv",
                  fileEncoding = "utf-8")
pop <- read_excel("total_populacao_sao_paulo.xlsx")

#Definindo a coluna id_municipio como numeric

pop <- pop %>% 
  mutate(id_municipio=as.numeric(id_municipio))

#Selecionando apenas as colunas de interesse da base pop

pop <- pop %>% 
  select(id_municipio,nome_municipio,pop_2010)

view(pop)

#Agregando as duas bases

dados <- dados %>% 
  left_join(pop)

view(dados)

#Selecionando as colunas de interesse da base final

dados <- dados %>% 
  select(ano:id_municipio,nome_municipio,pop_2010,
         homicidio_doloso:furto_de_veiculo)

view(dados)

dados <- dados %>% 
  mutate(ocorrencias_tot = select(.,
                                  homicidio_doloso:furto_de_veiculo) %>% 
  rowSums(na.rm = TRUE))

view(dados)

#dados <- dados %>% 
  #filter(!str_detect(Tipo,"^num"))

#Evolu��o dos crimes totais no Estado de S�o Paulo

grafico1 <- dados %>% 
  group_by(ano) %>%
  filter(ano<2021) %>% 
  summarise(ocorrencias_tot_ano = sum(ocorrencias_tot)/1000000) %>% 
  ggplot()+
  geom_line(aes(ano,ocorrencias_tot_ano),color = "darkred", size = 1) +
    labs(x = "Ano",
         y = "Ocorr�ncias totais (em milh�es)",
         title = "Evolu��o das Ocorr�ncias") +
    scale_y_continuous(n.breaks = 10) +
    scale_x_continuous(n.breaks = 12) +
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 12),
        panel.grid = element_blank(), 
        plot.background = element_rect(fill = "transparent", color = NA),
        panel.background = element_rect(fill = "transparent", color = NA),
        legend.background = element_rect(fill = "transparent", color = NA))

ggplotly(grafico1,tooltip="ocorrencias_tot_ano")

#Vendo a rela��o entre roubos de ve�culo e ocorr�ncias totais

grafico2 <- dados %>% 
  group_by(ano) %>%
  filter(ano<2021) %>% 
  summarise(roubos_veic_tot = sum(roubo_de_veiculo)/1000) %>% 
  ggplot()+
  geom_line(aes(ano,roubos_veic_tot),color = "darkblue", size = 1) +
  labs(x = "Ano",
       y = "Roubos de ve�culos (em milhares)",
       title = "Evolu��o dos roubos de ve�culo") +
  scale_y_continuous(n.breaks = 10) +
  scale_x_continuous(n.breaks = 12) +
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 12),
        panel.grid = element_blank(), 
        plot.background = element_rect(fill = "transparent", color = NA),
        panel.background = element_rect(fill = "transparent", color = NA),
        legend.background = element_rect(fill = "transparent", color = NA))

ggplotly(grafico2,tooltip="roubos_veic_tot")

#Comparando 

grid.arrange(grafico1,grafico2,ncol=2,nrow=1)

#Vendo as cidades mais perigosas em termos per capita do Estado de SP com bases
# em ocorr�ncias totais

cid_mais_perig <- dados %>% 
  filter(ano<2021) %>% 
  group_by(ano,nome_municipio) %>% 
  summarise(ocorrencias_tot_pop = sum(ocorrencias_tot)/pop_2010*1000) %>% 
  ggplot()+
  geom_line(aes(ano,ocorrencias_tot_pop, 
                group = nome_municipio, color = nome_municipio)) +
  labs(x = "Ano",
       y = "Ocorr�ncias totais por mil habitantes",
       title = "Evolu��o das Ocorr�ncias por mil habitantes") +
  scale_y_continuous(n.breaks = 10) +
  scale_x_continuous(n.breaks = 15) +
  theme_bw() +
  theme(axis.text.x = element_text(size = 10),
        axis.text.y = element_text(size = 12),
        panel.grid = element_blank(), 
        plot.background = element_rect(fill = "transparent", color = NA),
        panel.background = element_rect(fill = "transparent", color = NA),
        legend.background = element_rect(fill = "transparent", color = NA))

ggplotly(cid_mais_perig,tooltip = c("nome_municipio","ocorrencias_tot_pop"))

#An�lise comparativa dos crimes da cidade mais violenta com a menos violenta 
#(historicamente) em 2020 Descobrindo quais s�o as cidades mais violentas 
#e menos violentas

dados_mais_perig <- dados %>% 
  filter(ano==2020) %>% 
  group_by(ano,nome_municipio)

view(dados)

#Ilha Comprida

ilhacomprida_2020 <- dados_mais_perig %>% 
  select(-c(mes,nome_municipio,ocorrencias_tot,pop_2010)) %>% 
  pivot_longer(-c(ano,nome_municipio),
               names_to="Crime",
               values_to="Ocorrencias") %>% 
  group_by(nome_municipio,ano,Crime) %>% 
  summarise(Ocorrencias = sum(Ocorrencias)/pop_2010) %>% 
  filter(nome_municipio == "Ilha Comprida")


#Plotando o mapa de S�o Paulo 

coord_sp <- read_municipality(code_muni = 35, year = 2020)

mapa_sp <- coord_sp %>% 
  left_join(dados,by=c("code_muni"="id_municipio"))

view(mapa_sp)

###Araçatuba
aracatuba2020 <-  dados %>% 
  select(-c(mes,id_municipio,ocorrencias_tot)) %>% 
  pivot_longer(-c(ano,regiao_ssp),
               names_to="Crime",
               values_to="Ocorrencias") %>% 
  group_by(regiao_ssp,ano,Crime) %>% 
  summarize(Ocorrencias = sum(Ocorrencias)) %>% 
  filter(regiao_ssp == 'AraÃ§atuba',ano == 2020) 


aracatuba2020$Crime <- aracatuba2020$Crime %>% 
  str_replace_all("_"," ") %>% 
  str_to_title()


###Capital
###Capital
capital2020 <-  dados %>% 
  select(-c(mes,id_municipio,ocorrencias_tot)) %>% 
  pivot_longer(-c(ano,regiao_ssp),
               names_to="Crime",
               values_to="Ocorrencias") %>% 
  group_by(regiao_ssp,ano,Crime) %>% 
  summarize(Ocorrencias = sum(Ocorrencias)) %>% 
  filter(regiao_ssp == 'Capital',ano == 2020) %>% 
  mutate(Crime = fct_lump_n(as.factor(Crime), n=7, w=Ocorrencias, other_level = "Outros"))

capital2020$Crime <- capital2020$Crime %>% 
  str_replace_all("_"," ") %>% 
  str_to_title()


### Gráfico comparativo dos crimes da cidade menos violenta com a mais violenta
fig <- plot_ly()

fig<- fig %>% add_pie(data = aracatuba2020,
                      labels=~Crime,
                      values=~Ocorrencias,
                      name = "Araçatuba",
                      title = 'Araçatuba',
                      domain = list(row = 0, column = 0),
                      legendgroup=~Crime)

fig <- fig %>% add_pie(data = capital2020 %>% 
                         mutate(Crime = fct_lump(Crime,5)),
                       labels=~Crime,
                       values=~Ocorrencias,
                       name = "Capital",
                       title = "Capital",
                       domain = list(row = 0, column = 1))

fig <- fig %>% layout(title = "Crimes Araçatuba x Capital em 2020",
                      grid=list(rows=1, columns=2),
                      xaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE),
                      yaxis = list(showgrid = FALSE, zeroline = FALSE, showticklabels = FALSE))

fig


#####



mes2019<-dados %>% 
  filter(ano==2019) %>% 
  select(-c(ano,id_municipio,ocorrencias_tot)) %>% 
  pivot_longer(-c(mes,regiao_ssp),
               names_to="Crime",
               values_to="Ocorrencias") %>% 
  group_by(mes) %>% 
  summarize(Ocorrencias = sum(Ocorrencias))

mes2020<-dados %>% 
  filter(ano==2020) %>% 
  select(-c(ano,id_municipio,ocorrencias_tot)) %>% 
  pivot_longer(-c(mes,regiao_ssp),
               names_to="Crime",
               values_to="Ocorrencias") %>% 
  group_by(mes) %>% 
  summarize(Ocorrencias = sum(Ocorrencias))



graficomes2019 <- mes2019 %>%
  ggplot(aes(mes,Ocorrencias))+
        geom_bar(stat="identity")+
        theme_set(theme_bw())+
        scale_x_continuous(n.breaks=11)+
        labs(x = "Mês",
             y = "Ocorrências",
             title='2019')

graficomes2020 <- mes2020 %>%
  ggplot(aes(mes,Ocorrencias))+
  geom_bar(stat="identity")+
  theme_set(theme_bw())+
  scale_x_continuous(n.breaks=11)+
  labs(x = "Mês",
       y = "",
       title='2020')

grid.arrange(graficomes2019, graficomes2020, nrow = 1, top="Distribuição da quantidade de crimes ao longo dos meses")

#Plotando o mapa de S�o Paulo 

coord_sp <- read_municipality(code_muni = 35, year = 2020)

mapa_sp <- coord_sp %>% 
  left_join(dados,by=c("code_muni"="id_municipio"))

view(mapa_sp)

